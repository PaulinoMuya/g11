package pt.iade.getmatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetmatchApplication {
    public static void main(String[] args) {
        SpringApplication.run(GetmatchApplication.class, args);
    }
}

