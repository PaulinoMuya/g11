package pt.iade.getmatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetmatchApplicationTests {

    @Test
    void contextLoads() {
    }

}
